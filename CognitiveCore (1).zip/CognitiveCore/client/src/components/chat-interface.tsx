import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Send, Mic, Bot, User } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import VoiceRecorder from "./voice-recorder";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

interface ChatInterfaceProps {
  conversationId?: string;
  standalone?: boolean;
}

export default function ChatInterface({ conversationId, standalone = false }: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: messages = [], isLoading } = useQuery({
    queryKey: conversationId ? ['/api/conversations', conversationId, 'messages'] : ['chat-messages'],
    enabled: !!conversationId,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (conversationId) {
        const response = await apiRequest('POST', `/api/conversations/${conversationId}/messages`, {
          role: "user",
          content,
        });
        return response.json();
      } else {
        // Standalone chat mode
        const response = await apiRequest('POST', '/api/ai/chat', { message: content });
        return response.json();
      }
    },
    onSuccess: () => {
      setMessage("");
      if (conversationId) {
        queryClient.invalidateQueries({ queryKey: ['/api/conversations', conversationId, 'messages'] });
      }
    },
    onError: () => {
      toast({
        title: "Failed to send message",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!message.trim()) return;
    sendMessageMutation.mutate(message);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleVoiceTranscription = (text: string) => {
    setMessage(text);
    setShowVoiceRecorder(false);
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  if (standalone) {
    return (
      <Card className="flex flex-col h-96">
        <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
          <div className="space-y-4">
            <div className="flex space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
                <Bot className="text-white" size={16} />
              </div>
              <div className="flex-1">
                <div className="bg-white p-3 rounded-lg shadow-sm">
                  <p className="text-sm text-gray-800">
                    Hello! I'm your personal AI assistant. How can I help you today?
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div ref={messagesEndRef} />
        </div>
        
        <div className="p-4 border-t border-gray-200">
          <div className="flex space-x-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              disabled={sendMessageMutation.isPending}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!message.trim() || sendMessageMutation.isPending}
            >
              <Send size={16} />
            </Button>
            <Button
              variant="outline"
              onClick={() => setShowVoiceRecorder(true)}
            >
              <Mic size={16} />
            </Button>
          </div>
        </div>

        {showVoiceRecorder && (
          <VoiceRecorder 
            onClose={() => setShowVoiceRecorder(false)}
            onTranscription={handleVoiceTranscription}
          />
        )}
      </Card>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {isLoading ? (
          <div className="flex justify-center">
            <p className="text-gray-500">Loading messages...</p>
          </div>
        ) : (messages as Message[]).length === 0 ? (
          <div className="text-center text-gray-500">
            <Bot size={48} className="mx-auto mb-4 text-gray-300" />
            <p>Start a conversation with your AI assistant</p>
          </div>
        ) : (
          (messages as Message[]).map((msg: Message) => (
            <div key={msg.id} className={`flex space-x-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
              {msg.role === 'assistant' && (
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
                  <Bot className="text-white" size={16} />
                </div>
              )}
              <div className={`flex-1 max-w-xs lg:max-w-md ${msg.role === 'user' ? 'order-first' : ''}`}>
                <div className={`p-3 rounded-lg ${
                  msg.role === 'user'
                    ? 'bg-primary text-white ml-auto'
                    : 'bg-white shadow-sm'
                }`}>
                  <p className="text-sm">{msg.content}</p>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {new Date(msg.createdAt).toLocaleTimeString()}
                </p>
              </div>
              {msg.role === 'user' && (
                <div className="w-8 h-8 bg-gray-500 rounded-full flex items-center justify-center">
                  <User className="text-white" size={16} />
                </div>
              )}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-gray-200 bg-white">
        <div className="flex space-x-2">
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            disabled={sendMessageMutation.isPending}
          />
          <Button
            onClick={handleSendMessage}
            disabled={!message.trim() || sendMessageMutation.isPending}
          >
            <Send size={16} />
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowVoiceRecorder(true)}
          >
            <Mic size={16} />
          </Button>
        </div>
      </div>

      {showVoiceRecorder && (
        <VoiceRecorder 
          onClose={() => setShowVoiceRecorder(false)}
          onTranscription={handleVoiceTranscription}
        />
      )}
    </div>
  );
}
