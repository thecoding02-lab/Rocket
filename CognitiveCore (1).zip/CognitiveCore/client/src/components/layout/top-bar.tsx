import { Button } from "@/components/ui/button";
import { Mic, Plus, Bell } from "lucide-react";
import VoiceRecorder from "@/components/voice-recorder";
import { useState } from "react";

interface TopBarProps {
  title: string;
  description?: string;
  onQuickChat?: () => void;
}

export default function TopBar({ title, description, onQuickChat }: TopBarProps) {
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">{title}</h2>
          {description && (
            <p className="text-sm text-gray-500 mt-1">{description}</p>
          )}
        </div>
        <div className="flex items-center space-x-4">
          <Button
            onClick={() => setShowVoiceRecorder(true)}
            className="flex items-center space-x-2 bg-red-500 hover:bg-red-600 text-white"
          >
            <Mic size={16} />
            <span>Voice Input</span>
          </Button>
          
          {onQuickChat && (
            <Button
              onClick={onQuickChat}
              className="flex items-center space-x-2"
            >
              <Plus size={16} />
              <span>Quick Chat</span>
            </Button>
          )}
          
          <div className="relative">
            <Button variant="ghost" size="icon">
              <Bell size={20} />
            </Button>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
          </div>
        </div>
      </div>

      {showVoiceRecorder && (
        <VoiceRecorder onClose={() => setShowVoiceRecorder(false)} />
      )}
    </header>
  );
}
