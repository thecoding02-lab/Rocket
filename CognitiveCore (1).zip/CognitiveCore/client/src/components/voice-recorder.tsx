import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mic, MicOff, X } from "lucide-react";
import { useVoiceRecognition } from "@/hooks/use-voice-recognition";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface VoiceRecorderProps {
  onClose: () => void;
  onTranscription?: (text: string) => void;
}

export default function VoiceRecorder({ onClose, onTranscription }: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { transcript, isListening, startListening, stopListening, isSupported } = useVoiceRecognition();

  const transcribeMutation = useMutation({
    mutationFn: async (audioBlob: Blob) => {
      const formData = new FormData();
      formData.append('audio', audioBlob, 'recording.wav');
      const response = await apiRequest('POST', '/api/transcribe', formData);
      return response.json();
    },
    onSuccess: (data) => {
      if (onTranscription) {
        onTranscription(data.transcription);
      }
      toast({
        title: "Transcription Complete",
        description: "Audio has been successfully transcribed.",
      });
    },
    onError: () => {
      toast({
        title: "Transcription Failed",
        description: "Failed to transcribe audio. Please try again.",
        variant: "destructive",
      });
    },
  });

  const saveVoiceCommandMutation = useMutation({
    mutationFn: async (data: { command: string; transcription: string; response?: string }) => {
      const response = await apiRequest('POST', '/api/voice-commands', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/voice-commands'] });
    },
  });

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        transcribeMutation.mutate(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);

      // Also start web speech recognition if supported
      if (isSupported) {
        startListening();
      }
    } catch (error) {
      toast({
        title: "Recording Failed",
        description: "Failed to access microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }

    if (isListening) {
      stopListening();
    }

    // Save the voice command if we have a transcript
    if (transcript) {
      saveVoiceCommandMutation.mutate({
        command: "voice_input",
        transcription: transcript,
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md mx-4">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Voice Recorder</CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X size={20} />
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center space-y-4">
            <Button
              size="lg"
              onClick={isRecording ? stopRecording : startRecording}
              className={`w-20 h-20 rounded-full ${
                isRecording
                  ? "bg-red-500 hover:bg-red-600 recording-button"
                  : "bg-primary hover:bg-primary/90"
              }`}
              disabled={transcribeMutation.isPending}
            >
              {isRecording ? <MicOff size={24} /> : <Mic size={24} />}
            </Button>
            
            <p className="text-center text-sm text-gray-600">
              {isRecording
                ? "Recording... Click to stop"
                : "Click to start recording"}
            </p>

            {isListening && (
              <div className="text-center">
                <p className="text-sm text-blue-600 font-medium">Listening...</p>
                {transcript && (
                  <p className="text-sm text-gray-700 mt-2 p-3 bg-gray-50 rounded-lg">
                    {transcript}
                  </p>
                )}
              </div>
            )}

            {transcribeMutation.isPending && (
              <p className="text-sm text-gray-500">Transcribing audio...</p>
            )}

            {!isSupported && (
              <p className="text-xs text-amber-600 text-center">
                Web Speech API not supported. Audio will be transcribed using OpenAI Whisper.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
