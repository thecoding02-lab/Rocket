import { useState } from "react";
import TopBar from "@/components/layout/top-bar";
import ChatInterface from "@/components/chat-interface";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, MessageSquare, Trash2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Conversation {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
}

export default function AIChat() {
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [newConversationTitle, setNewConversationTitle] = useState("");
  const [showNewConversation, setShowNewConversation] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: conversations = [] } = useQuery<Conversation[]>({
    queryKey: ['/api/conversations'],
  });

  const createConversationMutation = useMutation({
    mutationFn: async (title: string) => {
      const response = await apiRequest('POST', '/api/conversations', { title });
      return response.json();
    },
    onSuccess: (newConversation) => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      setSelectedConversation(newConversation.id);
      setNewConversationTitle("");
      setShowNewConversation(false);
      toast({ title: "New conversation created" });
    },
    onError: () => {
      toast({
        title: "Failed to create conversation",
        variant: "destructive",
      });
    },
  });

  const deleteConversationMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/conversations/${id}`);
    },
    onSuccess: (_, deletedId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      if (selectedConversation === deletedId) {
        setSelectedConversation(null);
      }
      toast({ title: "Conversation deleted" });
    },
    onError: () => {
      toast({
        title: "Failed to delete conversation",
        variant: "destructive",
      });
    },
  });

  const handleCreateConversation = () => {
    if (newConversationTitle.trim()) {
      createConversationMutation.mutate(newConversationTitle);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <TopBar
        title="AI Chat"
        description="Have conversations with your personal AI assistant"
      />
      
      <main className="flex-1 overflow-hidden flex">
        {/* Conversations Sidebar */}
        <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <Button
              onClick={() => setShowNewConversation(true)}
              className="w-full"
            >
              <Plus size={16} className="mr-2" />
              New Conversation
            </Button>
          </div>

          {showNewConversation && (
            <div className="p-4 border-b border-gray-200 space-y-2">
              <Input
                placeholder="Conversation title"
                value={newConversationTitle}
                onChange={(e) => setNewConversationTitle(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleCreateConversation()}
              />
              <div className="flex space-x-2">
                <Button
                  onClick={handleCreateConversation}
                  disabled={!newConversationTitle.trim() || createConversationMutation.isPending}
                  size="sm"
                >
                  Create
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowNewConversation(false);
                    setNewConversationTitle("");
                  }}
                  size="sm"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto">
            {conversations.length === 0 ? (
              <div className="p-4 text-center text-gray-500">
                <MessageSquare size={48} className="mx-auto mb-4 text-gray-300" />
                <p>No conversations yet</p>
                <p className="text-sm">Create your first conversation to get started</p>
              </div>
            ) : (
              <div className="space-y-1 p-2">
                {conversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${
                      selectedConversation === conversation.id
                        ? "bg-primary/10 text-primary"
                        : "hover:bg-gray-100"
                    }`}
                    onClick={() => setSelectedConversation(conversation.id)}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{conversation.title}</p>
                      <p className="text-xs text-gray-500">
                        {new Date(conversation.updatedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteConversationMutation.mutate(conversation.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {selectedConversation ? (
            <ChatInterface conversationId={selectedConversation} />
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <MessageSquare size={64} className="mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Select a conversation to start chatting
                </h3>
                <p className="text-gray-500">
                  Choose an existing conversation or create a new one to begin
                </p>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
