import { useState } from "react";
import TopBar from "@/components/layout/top-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Code, Send, Copy, Check } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function CodeAssistant() {
  const [code, setCode] = useState("");
  const [query, setQuery] = useState("");
  const [response, setResponse] = useState("");
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const aiAssistMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest('POST', '/api/ai/chat', { message });
      return response.json();
    },
    onSuccess: (data) => {
      setResponse(data.response);
    },
    onError: () => {
      toast({
        title: "Failed to get AI assistance",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCodeReview = () => {
    if (!code.trim()) return;
    
    const message = `Please review this code and provide suggestions for improvement:\n\n\`\`\`\n${code}\n\`\`\``;
    aiAssistMutation.mutate(message);
  };

  const handleQuerySubmit = () => {
    if (!query.trim()) return;
    
    const message = code.trim() 
      ? `${query}\n\nHere's my code for context:\n\n\`\`\`\n${code}\n\`\`\``
      : query;
    
    aiAssistMutation.mutate(message);
    setQuery("");
  };

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({ title: "Copied to clipboard" });
    } catch (error) {
      toast({
        title: "Failed to copy",
        variant: "destructive",
      });
    }
  };

  const codeExamples = [
    {
      title: "Debug this function",
      description: "Find and fix bugs in your code",
    },
    {
      title: "Optimize performance",
      description: "Get suggestions to improve code efficiency",
    },
    {
      title: "Add error handling",
      description: "Implement proper error handling patterns",
    },
    {
      title: "Write unit tests",
      description: "Generate test cases for your functions",
    },
    {
      title: "Refactor code",
      description: "Improve code structure and readability",
    },
    {
      title: "Add documentation",
      description: "Generate comments and documentation",
    },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <TopBar
        title="Code Assistant"
        description="Get AI-powered help with your coding tasks and questions"
      />
      
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Code Input Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Code size={20} />
                <span>Your Code</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Paste your code here for review, debugging, or questions..."
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="min-h-[300px] font-mono text-sm"
              />
              <div className="flex space-x-2 mt-4">
                <Button 
                  onClick={handleCodeReview}
                  disabled={!code.trim() || aiAssistMutation.isPending}
                >
                  Review Code
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setCode("")}
                >
                  Clear
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>AI Response</CardTitle>
            </CardHeader>
            <CardContent>
              {aiAssistMutation.isPending ? (
                <div className="flex items-center justify-center min-h-[300px]">
                  <p className="text-gray-500">Analyzing your code...</p>
                </div>
              ) : response ? (
                <div>
                  <div className="bg-gray-50 rounded-lg p-4 min-h-[300px] whitespace-pre-wrap font-mono text-sm">
                    {response}
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => handleCopy(response)}
                    className="mt-4"
                  >
                    {copied ? <Check size={16} /> : <Copy size={16} />}
                    <span className="ml-2">{copied ? "Copied!" : "Copy Response"}</span>
                  </Button>
                </div>
              ) : (
                <div className="flex items-center justify-center min-h-[300px] text-gray-500">
                  <div className="text-center">
                    <Code size={48} className="mx-auto mb-4 text-gray-300" />
                    <p>AI response will appear here</p>
                    <p className="text-sm">Paste code and click "Review Code" or ask a question below</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Query Section */}
        <Card>
          <CardHeader>
            <CardTitle>Ask a Question</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-2">
              <Textarea
                placeholder="Ask about programming concepts, debugging help, best practices, etc."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="flex-1"
                rows={3}
              />
              <Button
                onClick={handleQuerySubmit}
                disabled={!query.trim() || aiAssistMutation.isPending}
                className="self-end"
              >
                <Send size={16} />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {codeExamples.map((example, index) => (
                <div
                  key={index}
                  className="p-4 border border-gray-200 rounded-lg hover:border-gray-300 cursor-pointer transition-colors"
                  onClick={() => {
                    if (code.trim()) {
                      aiAssistMutation.mutate(`${example.title} for this code:\n\n\`\`\`\n${code}\n\`\`\``);
                    } else {
                      setQuery(`How do I ${example.title.toLowerCase()}?`);
                    }
                  }}
                >
                  <h4 className="font-medium text-gray-900 mb-2">{example.title}</h4>
                  <p className="text-sm text-gray-600">{example.description}</p>
                  <Badge variant="outline" className="mt-2">
                    Click to use
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Programming Languages Support */}
        <Card>
          <CardHeader>
            <CardTitle>Supported Languages & Technologies</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {[
                "JavaScript", "TypeScript", "Python", "Java", "C++", "C#", "Go", "Rust",
                "React", "Node.js", "Vue.js", "Angular", "Express", "Django", "Flask",
                "SQL", "MongoDB", "PostgreSQL", "Docker", "Kubernetes", "AWS", "Git"
              ].map((tech) => (
                <Badge key={tech} variant="secondary">
                  {tech}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
