import { useQuery } from "@tanstack/react-query";
import TopBar from "@/components/layout/top-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import TaskManager from "@/components/task-manager";
import ChatInterface from "@/components/chat-interface";
import FileUpload from "@/components/file-upload";
import VoiceRecorder from "@/components/voice-recorder";
import { useState } from "react";
import {
  CheckSquare,
  MessageSquare,
  Mic,
  Code,
  Brain,
  TrendingUp,
  BarChart3,
  Activity
} from "lucide-react";

interface Stats {
  totalTasks: number;
  completedTasks: number;
  conversations: number;
  voiceCommands: number;
  codeAssists: number;
}

export default function Dashboard() {
  const [showQuickChat, setShowQuickChat] = useState(false);
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);

  const { data: stats } = useQuery<Stats>({
    queryKey: ['/api/stats'],
  });

  const statsCards = [
    {
      title: "Total Tasks",
      value: stats?.totalTasks || 0,
      change: "+12% from last week",
      icon: CheckSquare,
      color: "bg-blue-100 text-blue-600",
    },
    {
      title: "AI Conversations",
      value: stats?.conversations || 0,
      change: "+8% from last week",
      icon: MessageSquare,
      color: "bg-violet-100 text-violet-600",
    },
    {
      title: "Voice Commands",
      value: stats?.voiceCommands || 0,
      change: "+23% from last week",
      icon: Mic,
      color: "bg-green-100 text-green-600",
    },
    {
      title: "Code Assists",
      value: stats?.codeAssists || 0,
      change: "+15% from last week",
      icon: Code,
      color: "bg-orange-100 text-orange-600",
    },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <TopBar
        title="Dashboard"
        description="Manage your AI assistant and personal data"
        onQuickChat={() => setShowQuickChat(true)}
      />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statsCards.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.title}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                    </div>
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${stat.color}`}>
                      <Icon size={24} />
                    </div>
                  </div>
                  <div className="mt-4">
                    <span className="text-sm text-accent">{stat.change}</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Task Manager */}
          <div className="lg:col-span-2">
            <TaskManager />
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            {/* AI Chat Quick Access */}
            <Card>
              <CardHeader>
                <CardTitle>Quick AI Chat</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">Ready to assist you with:</p>
                  <ul className="text-sm font-medium text-gray-900 mt-1 space-y-1">
                    <li>• Task management</li>
                    <li>• Code assistance</li>
                    <li>• General questions</li>
                  </ul>
                </div>
                <Button 
                  className="w-full bg-gradient-to-r from-primary to-secondary hover:from-blue-600 hover:to-violet-600"
                  onClick={() => setShowQuickChat(true)}
                >
                  <MessageSquare className="mr-2" size={16} />
                  Start AI Conversation
                </Button>
              </CardContent>
            </Card>

            {/* Voice Commands */}
            <Card>
              <CardHeader>
                <CardTitle>Voice Commands</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-red-50 rounded-lg border border-red-200">
                  <div className="flex items-center justify-center">
                    <Button
                      size="lg"
                      className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600"
                      onClick={() => setShowVoiceRecorder(true)}
                    >
                      <Mic size={24} />
                    </Button>
                  </div>
                  <p className="text-center text-sm text-gray-600 mt-2">
                    Click to start voice recording
                  </p>
                </div>
                <div className="text-xs text-gray-500">
                  <p><strong>Try saying:</strong></p>
                  <ul className="mt-1 space-y-1">
                    <li>"Create task for project review"</li>
                    <li>"Show me today's schedule"</li>
                    <li>"Start coding session"</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Quick Upload */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Upload</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-gray-400 transition-colors cursor-pointer">
                  <svg className="mx-auto mb-2 text-gray-400" width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                  </svg>
                  <p className="text-sm text-gray-600">Drop files here or click to upload</p>
                  <p className="text-xs text-gray-500 mt-1">Documents, images, code files</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* AI Learning Section */}
        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>AI Learning & Insights</CardTitle>
              <p className="text-sm text-gray-500">Your AI agent's learning progress and insights</p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                      <Brain className="text-white" size={20} />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Pattern Recognition</h4>
                      <p className="text-sm text-gray-600">Learning your work habits</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="w-full bg-blue-200 rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full" style={{ width: "75%" }}></div>
                    </div>
                    <p className="text-xs text-gray-600 mt-1">75% confidence level</p>
                  </div>
                </div>

                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                      <TrendingUp className="text-white" size={20} />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Smart Suggestions</h4>
                      <p className="text-sm text-gray-600">Proactive recommendations</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="w-full bg-green-200 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: "60%" }}></div>
                    </div>
                    <p className="text-xs text-gray-600 mt-1">60% accuracy rate</p>
                  </div>
                </div>

                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                      <BarChart3 className="text-white" size={20} />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Performance Tracking</h4>
                      <p className="text-sm text-gray-600">Monitoring improvements</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="w-full bg-purple-200 rounded-full h-2">
                      <div className="bg-purple-500 h-2 rounded-full" style={{ width: "85%" }}></div>
                    </div>
                    <p className="text-xs text-gray-600 mt-1">85% task completion</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Quick Chat Modal */}
      {showQuickChat && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl h-96 flex flex-col mx-4">
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">AI Assistant</h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowQuickChat(false)}
              >
                ×
              </Button>
            </div>
            <div className="flex-1">
              <ChatInterface standalone />
            </div>
          </div>
        </div>
      )}

      {/* Voice Recorder Modal */}
      {showVoiceRecorder && (
        <VoiceRecorder onClose={() => setShowVoiceRecorder(false)} />
      )}

      {/* Floating Chat Button */}
      <Button
        onClick={() => setShowQuickChat(true)}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-lg hover:shadow-xl bg-gradient-to-r from-primary to-secondary"
        size="icon"
      >
        <MessageSquare size={24} />
      </Button>
    </div>
  );
}
