import TopBar from "@/components/layout/top-bar";
import FileUpload from "@/components/file-upload";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Database, 
  FileText, 
  Image, 
  Video, 
  Music, 
  Archive,
  Trash2,
  Download,
  Eye,
  Search
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { useState } from "react";

interface FileItem {
  id: string;
  filename: string;
  originalName: string;
  mimetype: string;
  size: number;
  description?: string;
  createdAt: string;
}

interface StorageStats {
  totalFiles: number;
  totalSize: number;
  byType: {
    images: number;
    documents: number;
    videos: number;
    audio: number;
    other: number;
  };
}

export default function DataStorage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState<string>("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: files = [], isLoading } = useQuery<FileItem[]>({
    queryKey: ['/api/files'],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/files/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({ title: "File deleted successfully" });
    },
    onError: () => {
      toast({
        title: "Failed to delete file",
        variant: "destructive",
      });
    },
  });

  const getStorageStats = (): StorageStats => {
    const stats = {
      totalFiles: files.length,
      totalSize: files.reduce((sum, file) => sum + file.size, 0),
      byType: {
        images: 0,
        documents: 0,
        videos: 0,
        audio: 0,
        other: 0,
      },
    };

    files.forEach((file) => {
      if (file.mimetype.startsWith('image/')) {
        stats.byType.images++;
      } else if (file.mimetype.startsWith('video/')) {
        stats.byType.videos++;
      } else if (file.mimetype.startsWith('audio/')) {
        stats.byType.audio++;
      } else if (
        file.mimetype.includes('pdf') ||
        file.mimetype.includes('document') ||
        file.mimetype.includes('text') ||
        file.mimetype.includes('spreadsheet')
      ) {
        stats.byType.documents++;
      } else {
        stats.byType.other++;
      }
    });

    return stats;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (mimetype: string, size: number = 24) => {
    if (mimetype.startsWith('image/')) return <Image size={size} className="text-green-600" />;
    if (mimetype.startsWith('video/')) return <Video size={size} className="text-red-600" />;
    if (mimetype.startsWith('audio/')) return <Music size={size} className="text-purple-600" />;
    if (mimetype.includes('pdf') || mimetype.includes('document')) return <FileText size={size} className="text-blue-600" />;
    return <Archive size={size} className="text-gray-600" />;
  };

  const filteredFiles = files.filter((file) => {
    const matchesSearch = file.originalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (file.description && file.description.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (!matchesSearch) return false;

    if (selectedType === "all") return true;
    
    switch (selectedType) {
      case "images":
        return file.mimetype.startsWith('image/');
      case "documents":
        return file.mimetype.includes('pdf') || 
               file.mimetype.includes('document') || 
               file.mimetype.includes('text');
      case "videos":
        return file.mimetype.startsWith('video/');
      case "audio":
        return file.mimetype.startsWith('audio/');
      default:
        return true;
    }
  });

  const stats = getStorageStats();

  const fileTypeOptions = [
    { id: "all", name: "All Files", count: stats.totalFiles, icon: Database },
    { id: "images", name: "Images", count: stats.byType.images, icon: Image },
    { id: "documents", name: "Documents", count: stats.byType.documents, icon: FileText },
    { id: "videos", name: "Videos", count: stats.byType.videos, icon: Video },
    { id: "audio", name: "Audio", count: stats.byType.audio, icon: Music },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <TopBar
        title="Data Storage"
        description="Manage your uploaded files and documents"
      />
      
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Storage Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Files</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalFiles}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Database className="text-blue-600" size={24} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Size</p>
                  <p className="text-2xl font-bold text-gray-900">{formatFileSize(stats.totalSize)}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Archive className="text-green-600" size={24} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Images</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.byType.images}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Image className="text-green-600" size={24} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Documents</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.byType.documents}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="text-blue-600" size={24} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* File Upload */}
          <div className="lg:col-span-3">
            <FileUpload />
          </div>

          {/* File Type Filters */}
          <Card>
            <CardHeader>
              <CardTitle>File Types</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {fileTypeOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <Button
                    key={option.id}
                    variant={selectedType === option.id ? "default" : "outline"}
                    className="w-full justify-start"
                    onClick={() => setSelectedType(option.id)}
                  >
                    <Icon size={16} className="mr-2" />
                    <span className="flex-1 text-left">{option.name}</span>
                    <Badge variant="secondary">{option.count}</Badge>
                  </Button>
                );
              })}
            </CardContent>
          </Card>
        </div>

        {/* File Browser */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>File Browser</CardTitle>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                  <Input
                    placeholder="Search files..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                ))}
              </div>
            ) : filteredFiles.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Database size={48} className="mx-auto mb-4 text-gray-300" />
                <p>No files found</p>
                <p className="text-sm">
                  {searchQuery || selectedType !== "all" 
                    ? "Try adjusting your search or filter"
                    : "Upload your first file to get started"
                  }
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      {getFileIcon(file.mimetype)}
                      <div>
                        <p className="font-medium text-gray-900">{file.originalName}</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-500">
                          <span>{formatFileSize(file.size)}</span>
                          <span>•</span>
                          <span>{new Date(file.createdAt).toLocaleDateString()}</span>
                          {file.description && (
                            <>
                              <span>•</span>
                              <span className="truncate max-w-xs">{file.description}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="icon" title="Preview">
                        <Eye size={16} />
                      </Button>
                      <Button variant="ghost" size="icon" title="Download">
                        <Download size={16} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteMutation.mutate(file.id)}
                        title="Delete"
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
