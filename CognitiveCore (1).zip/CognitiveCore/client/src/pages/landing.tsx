import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Bot, Brain, MessageSquare, Code, Database, Mic, CheckSquare, Settings } from "lucide-react";

export default function Landing() {
  const features = [
    {
      title: "AI Chat Assistant",
      description: "Have intelligent conversations with your personal AI assistant powered by advanced language models.",
      icon: MessageSquare,
    },
    {
      title: "Smart Task Management", 
      description: "Organize and track your tasks with AI-powered insights and priority recommendations.",
      icon: CheckSquare,
    },
    {
      title: "Voice Commands",
      description: "Control your assistant with voice commands and get audio transcriptions.",
      icon: Mic,
    },
    {
      title: "Code Assistant",
      description: "Get expert code reviews, suggestions, and programming assistance across multiple languages.",
      icon: Code,
    },
    {
      title: "Learning Analytics",
      description: "Track your learning progress and get personalized insights to improve your skills.",
      icon: Brain,
    },
    {
      title: "Secure Data Storage",
      description: "Store and manage your files securely with intelligent organization and search.",
      icon: Database,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
              <Bot className="text-white text-2xl" />
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Your Personal
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent"> AI Assistant</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Experience the future of productivity with an intelligent assistant that learns, adapts, and grows with you. 
            Manage tasks, analyze code, store data, and have meaningful conversations—all in one secure platform.
          </p>
          <Button 
            size="lg" 
            className="px-8 py-4 text-lg"
            onClick={() => window.location.href = "/api/login"}
          >
            Get Started
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="text-primary" size={24} />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center">
          <Card className="max-w-4xl mx-auto">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Exclusive Personal Use
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                This AI assistant is designed exclusively for your personal use. Your data remains private and secure, 
                with no sharing or external access. Experience the peace of mind that comes with a truly personal AI companion.
              </p>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Settings className="text-green-600" size={24} />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Fully Customizable</h3>
                  <p className="text-gray-600 text-sm">Tailor the assistant to your specific needs and preferences</p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Database className="text-blue-600" size={24} />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Private & Secure</h3>
                  <p className="text-gray-600 text-sm">Your conversations and data stay completely private</p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Brain className="text-purple-600" size={24} />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Continuously Learning</h3>
                  <p className="text-gray-600 text-sm">Learns from your interactions to provide better assistance</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}