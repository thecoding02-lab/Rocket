import { useState } from "react";
import TopBar from "@/components/layout/top-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Brain, 
  TrendingUp, 
  BarChart3, 
  Lightbulb, 
  Target, 
  Activity,
  Clock,
  CheckCircle,
  AlertCircle
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface LearningDataItem {
  id: string;
  category: string;
  key: string;
  value: any;
  confidence: number;
  createdAt: string;
  updatedAt: string;
}

interface LearningInsight {
  patterns: string[];
  suggestions: string[];
  insights: string[];
}

export default function LearningHub() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: learningData = [], isLoading: loadingData } = useQuery<LearningDataItem[]>({
    queryKey: selectedCategory === "all" ? ['/api/learning-data'] : ['/api/learning-data', { category: selectedCategory }],
  });

  const { data: stats } = useQuery({
    queryKey: ['/api/stats'],
  });

  const generateInsightsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/ai/chat', {
        message: `Analyze my usage patterns and provide learning insights based on my activity: ${JSON.stringify(stats)}`
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Insights generated successfully" });
      queryClient.invalidateQueries({ queryKey: ['/api/learning-data'] });
    },
    onError: () => {
      toast({
        title: "Failed to generate insights",
        variant: "destructive",
      });
    },
  });

  const learningCategories = [
    { id: "all", name: "All Categories", icon: Brain },
    { id: "pattern", name: "Patterns", icon: TrendingUp },
    { id: "preference", name: "Preferences", icon: Target },
    { id: "habit", name: "Habits", icon: Activity },
  ];

  const getLearningMetrics = () => {
    const patterns = learningData.filter(item => item.category === "pattern");
    const preferences = learningData.filter(item => item.category === "preference");
    const habits = learningData.filter(item => item.category === "habit");
    
    const avgConfidence = learningData.length > 0 
      ? learningData.reduce((sum, item) => sum + item.confidence, 0) / learningData.length 
      : 0;

    return {
      totalInsights: learningData.length,
      patterns: patterns.length,
      preferences: preferences.length,
      habits: habits.length,
      avgConfidence: Math.round(avgConfidence),
    };
  };

  const metrics = getLearningMetrics();

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return "text-green-600 bg-green-100";
    if (confidence >= 60) return "text-blue-600 bg-blue-100";
    if (confidence >= 40) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  const formatValue = (value: any) => {
    if (typeof value === "object") {
      return JSON.stringify(value, null, 2);
    }
    return String(value);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <TopBar
        title="Learning Hub"
        description="Track your AI agent's learning progress and insights"
      />
      
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Learning Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Insights</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.totalInsights}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Brain className="text-blue-600" size={24} />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-sm text-green-600">Learning actively</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Patterns Found</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.patterns}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="text-green-600" size={24} />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-sm text-green-600">+{Math.floor(Math.random() * 10) + 1} this week</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Confidence Level</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.avgConfidence}%</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <BarChart3 className="text-purple-600" size={24} />
                </div>
              </div>
              <div className="mt-4">
                <Progress value={metrics.avgConfidence} className="h-2" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Habits</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.habits}</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Activity className="text-orange-600" size={24} />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-sm text-blue-600">Tracking behavior</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Learning Progress */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>AI Learning Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                      <Brain className="text-white" size={20} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">Pattern Recognition</h4>
                      <p className="text-sm text-gray-600">Learning your work habits and preferences</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Progress</span>
                      <span>75%</span>
                    </div>
                    <Progress value={75} className="h-2" />
                    <p className="text-xs text-gray-600 mt-1">High confidence in task patterns</p>
                  </div>
                </div>

                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                      <Lightbulb className="text-white" size={20} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">Smart Suggestions</h4>
                      <p className="text-sm text-gray-600">Generating proactive recommendations</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Accuracy</span>
                      <span>68%</span>
                    </div>
                    <Progress value={68} className="h-2" />
                    <p className="text-xs text-gray-600 mt-1">Improving suggestion relevance</p>
                  </div>
                </div>

                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                      <Target className="text-white" size={20} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">Goal Tracking</h4>
                      <p className="text-sm text-gray-600">Understanding your objectives</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Completion</span>
                      <span>82%</span>
                    </div>
                    <Progress value={82} className="h-2" />
                    <p className="text-xs text-gray-600 mt-1">Excellent goal completion rate</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={() => generateInsightsMutation.mutate()}
                disabled={generateInsightsMutation.isPending}
                className="w-full"
              >
                <Brain className="mr-2" size={16} />
                Generate New Insights
              </Button>

              <div className="space-y-3">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <CheckCircle className="text-green-500" size={16} />
                    <span className="text-sm font-medium">Most Productive Time</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    You're most active between 9 AM - 11 AM
                  </p>
                </div>

                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertCircle className="text-blue-500" size={16} />
                    <span className="text-sm font-medium">Task Preference</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    You prefer breaking large tasks into smaller ones
                  </p>
                </div>

                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Clock className="text-purple-500" size={16} />
                    <span className="text-sm font-medium">Response Pattern</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    You typically respond to AI suggestions within 5 minutes
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Learning Data */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Learning Data</CardTitle>
              <div className="flex space-x-2">
                {learningCategories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <category.icon size={16} className="mr-1" />
                    {category.name}
                  </Button>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loadingData ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                ))}
              </div>
            ) : learningData.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Brain size={48} className="mx-auto mb-4 text-gray-300" />
                <p>No learning data available yet</p>
                <p className="text-sm">Continue using the system to generate insights</p>
              </div>
            ) : (
              <div className="space-y-4">
                {learningData.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 bg-gray-50 rounded-lg border border-gray-200"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge variant="outline">{item.category}</Badge>
                          <Badge className={getConfidenceColor(item.confidence)}>
                            {item.confidence}% confidence
                          </Badge>
                          <span className="text-sm text-gray-500">
                            {new Date(item.updatedAt).toLocaleDateString()}
                          </span>
                        </div>
                        
                        <div className="space-y-2">
                          <div>
                            <p className="text-sm font-medium text-gray-700">Key:</p>
                            <p className="text-gray-900">{item.key}</p>
                          </div>
                          
                          <div>
                            <p className="text-sm font-medium text-gray-700">Value:</p>
                            <pre className="text-sm text-gray-900 bg-white p-2 rounded border">
                              {formatValue(item.value)}
                            </pre>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
