import { useState } from "react";
import TopBar from "@/components/layout/top-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  Settings as SettingsIcon, 
  User, 
  Bell, 
  Mic, 
  Brain, 
  Shield, 
  Palette,
  Download,
  Upload,
  Trash2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface UserSettings {
  notifications: {
    email: boolean;
    push: boolean;
    sounds: boolean;
  };
  voice: {
    enabled: boolean;
    language: string;
    autoTranscribe: boolean;
  };
  ai: {
    personalityMode: string;
    responseLength: string;
    learningEnabled: boolean;
    contextMemory: boolean;
  };
  privacy: {
    dataCollection: boolean;
    analytics: boolean;
    shareInsights: boolean;
  };
  appearance: {
    theme: string;
    language: string;
    timezone: string;
  };
}

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [settings, setSettings] = useState<UserSettings>({
    notifications: {
      email: true,
      push: true,
      sounds: false,
    },
    voice: {
      enabled: true,
      language: "en-US",
      autoTranscribe: true,
    },
    ai: {
      personalityMode: "professional",
      responseLength: "balanced",
      learningEnabled: true,
      contextMemory: true,
    },
    privacy: {
      dataCollection: true,
      analytics: false,
      shareInsights: false,
    },
    appearance: {
      theme: "light",
      language: "en",
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    },
  });

  const [profileData, setProfileData] = useState({
    name: "Personal User",
    email: "user@example.com",
    bio: "AI Assistant user focused on productivity and learning.",
  });

  const saveSettingsMutation = useMutation({
    mutationFn: async (newSettings: UserSettings) => {
      // In a real app, this would save to the backend
      const response = await apiRequest('POST', '/api/learning-data', {
        category: "preference",
        key: "user_settings",
        value: newSettings,
        confidence: 100,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Settings saved successfully" });
      queryClient.invalidateQueries({ queryKey: ['/api/learning-data'] });
    },
    onError: () => {
      toast({
        title: "Failed to save settings",
        variant: "destructive",
      });
    },
  });

  const exportDataMutation = useMutation({
    mutationFn: async () => {
      // In a real app, this would generate and download user data
      const data = {
        settings,
        profile: profileData,
        exportDate: new Date().toISOString(),
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ai-assistant-data-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      return data;
    },
    onSuccess: () => {
      toast({ title: "Data exported successfully" });
    },
    onError: () => {
      toast({
        title: "Failed to export data",
        variant: "destructive",
      });
    },
  });

  const handleSettingChange = (category: keyof UserSettings, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value,
      },
    }));
  };

  const handleSaveSettings = () => {
    saveSettingsMutation.mutate(settings);
  };

  const handleResetSettings = () => {
    // Reset to default settings
    setSettings({
      notifications: { email: true, push: true, sounds: false },
      voice: { enabled: true, language: "en-US", autoTranscribe: true },
      ai: { personalityMode: "professional", responseLength: "balanced", learningEnabled: true, contextMemory: true },
      privacy: { dataCollection: true, analytics: false, shareInsights: false },
      appearance: { theme: "light", language: "en", timezone: Intl.DateTimeFormat().resolvedOptions().timeZone },
    });
    toast({ title: "Settings reset to defaults" });
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <TopBar
        title="Settings"
        description="Customize your AI assistant experience and preferences"
      />
      
      <main className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="voice">Voice</TabsTrigger>
              <TabsTrigger value="ai">AI Settings</TabsTrigger>
              <TabsTrigger value="privacy">Privacy</TabsTrigger>
              <TabsTrigger value="appearance">Appearance</TabsTrigger>
            </TabsList>

            {/* Profile Settings */}
            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <User size={20} />
                    <span>Profile Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Display Name</Label>
                      <Input
                        id="name"
                        value={profileData.name}
                        onChange={(e) => setProfileData(prev => ({ ...prev, name: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        value={profileData.email}
                        onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      value={profileData.bio}
                      onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                      placeholder="Tell your AI assistant about yourself..."
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notification Settings */}
            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Bell size={20} />
                    <span>Notification Preferences</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Email Notifications</Label>
                      <p className="text-sm text-gray-500">Receive updates via email</p>
                    </div>
                    <Switch
                      checked={settings.notifications.email}
                      onCheckedChange={(value) => handleSettingChange('notifications', 'email', value)}
                    />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Push Notifications</Label>
                      <p className="text-sm text-gray-500">Browser notifications for important updates</p>
                    </div>
                    <Switch
                      checked={settings.notifications.push}
                      onCheckedChange={(value) => handleSettingChange('notifications', 'push', value)}
                    />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Sound Notifications</Label>
                      <p className="text-sm text-gray-500">Play sounds for notifications</p>
                    </div>
                    <Switch
                      checked={settings.notifications.sounds}
                      onCheckedChange={(value) => handleSettingChange('notifications', 'sounds', value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Voice Settings */}
            <TabsContent value="voice">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Mic size={20} />
                    <span>Voice & Speech Settings</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Voice Commands</Label>
                      <p className="text-sm text-gray-500">Enable voice input and commands</p>
                    </div>
                    <Switch
                      checked={settings.voice.enabled}
                      onCheckedChange={(value) => handleSettingChange('voice', 'enabled', value)}
                    />
                  </div>
                  <Separator />
                  <div>
                    <Label htmlFor="voice-language">Voice Language</Label>
                    <Select
                      value={settings.voice.language}
                      onValueChange={(value) => handleSettingChange('voice', 'language', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en-US">English (US)</SelectItem>
                        <SelectItem value="en-GB">English (UK)</SelectItem>
                        <SelectItem value="es-ES">Spanish</SelectItem>
                        <SelectItem value="fr-FR">French</SelectItem>
                        <SelectItem value="de-DE">German</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Auto-Transcribe</Label>
                      <p className="text-sm text-gray-500">Automatically transcribe voice recordings</p>
                    </div>
                    <Switch
                      checked={settings.voice.autoTranscribe}
                      onCheckedChange={(value) => handleSettingChange('voice', 'autoTranscribe', value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* AI Settings */}
            <TabsContent value="ai">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain size={20} />
                    <span>AI Behavior & Learning</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label htmlFor="personality">AI Personality Mode</Label>
                    <Select
                      value={settings.ai.personalityMode}
                      onValueChange={(value) => handleSettingChange('ai', 'personalityMode', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="professional">Professional</SelectItem>
                        <SelectItem value="friendly">Friendly</SelectItem>
                        <SelectItem value="casual">Casual</SelectItem>
                        <SelectItem value="technical">Technical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Separator />
                  <div>
                    <Label htmlFor="response-length">Response Length</Label>
                    <Select
                      value={settings.ai.responseLength}
                      onValueChange={(value) => handleSettingChange('ai', 'responseLength', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="concise">Concise</SelectItem>
                        <SelectItem value="balanced">Balanced</SelectItem>
                        <SelectItem value="detailed">Detailed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Learning Enabled</Label>
                      <p className="text-sm text-gray-500">Allow AI to learn from interactions</p>
                    </div>
                    <Switch
                      checked={settings.ai.learningEnabled}
                      onCheckedChange={(value) => handleSettingChange('ai', 'learningEnabled', value)}
                    />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Context Memory</Label>
                      <p className="text-sm text-gray-500">Remember conversation context</p>
                    </div>
                    <Switch
                      checked={settings.ai.contextMemory}
                      onCheckedChange={(value) => handleSettingChange('ai', 'contextMemory', value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Privacy Settings */}
            <TabsContent value="privacy">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield size={20} />
                    <span>Privacy & Data</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Data Collection</Label>
                      <p className="text-sm text-gray-500">Allow collection of usage data for improvement</p>
                    </div>
                    <Switch
                      checked={settings.privacy.dataCollection}
                      onCheckedChange={(value) => handleSettingChange('privacy', 'dataCollection', value)}
                    />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Analytics</Label>
                      <p className="text-sm text-gray-500">Share anonymous analytics data</p>
                    </div>
                    <Switch
                      checked={settings.privacy.analytics}
                      onCheckedChange={(value) => handleSettingChange('privacy', 'analytics', value)}
                    />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Share Insights</Label>
                      <p className="text-sm text-gray-500">Share learning insights with development team</p>
                    </div>
                    <Switch
                      checked={settings.privacy.shareInsights}
                      onCheckedChange={(value) => handleSettingChange('privacy', 'shareInsights', value)}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-4">
                    <h4 className="font-medium">Data Management</h4>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        onClick={() => exportDataMutation.mutate()}
                        disabled={exportDataMutation.isPending}
                      >
                        <Download size={16} className="mr-2" />
                        Export My Data
                      </Button>
                      <Button variant="outline">
                        <Upload size={16} className="mr-2" />
                        Import Data
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Appearance Settings */}
            <TabsContent value="appearance">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Palette size={20} />
                    <span>Appearance & Localization</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label htmlFor="theme">Theme</Label>
                    <Select
                      value={settings.appearance.theme}
                      onValueChange={(value) => handleSettingChange('appearance', 'theme', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="system">System</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Separator />
                  <div>
                    <Label htmlFor="language">Interface Language</Label>
                    <Select
                      value={settings.appearance.language}
                      onValueChange={(value) => handleSettingChange('appearance', 'language', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="es">Spanish</SelectItem>
                        <SelectItem value="fr">French</SelectItem>
                        <SelectItem value="de">German</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Separator />
                  <div>
                    <Label htmlFor="timezone">Timezone</Label>
                    <Input
                      id="timezone"
                      value={settings.appearance.timezone}
                      onChange={(e) => handleSettingChange('appearance', 'timezone', e.target.value)}
                      placeholder="Enter timezone"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Action Buttons */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex justify-between items-center">
                <Button
                  variant="outline"
                  onClick={handleResetSettings}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 size={16} className="mr-2" />
                  Reset to Defaults
                </Button>
                
                <div className="space-x-2">
                  <Button variant="outline">
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSaveSettings}
                    disabled={saveSettingsMutation.isPending}
                  >
                    <SettingsIcon size={16} className="mr-2" />
                    Save Settings
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
