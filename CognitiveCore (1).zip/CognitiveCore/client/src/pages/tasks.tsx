import TopBar from "@/components/layout/top-bar";
import TaskManager from "@/components/task-manager";

export default function Tasks() {
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <TopBar
        title="Tasks"
        description="Manage your personal tasks and to-do items"
      />
      
      <main className="flex-1 overflow-y-auto p-6">
        <TaskManager />
      </main>
    </div>
  );
}
