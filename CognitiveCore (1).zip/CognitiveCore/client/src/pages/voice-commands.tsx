import { useState } from "react";
import TopBar from "@/components/layout/top-bar";
import VoiceRecorder from "@/components/voice-recorder";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Mic, Volume2, VolumeX } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useSpeechSynthesis } from "@/hooks/use-speech-synthesis";

interface VoiceCommand {
  id: string;
  command: string;
  transcription: string;
  response?: string;
  success: boolean;
  createdAt: string;
}

export default function VoiceCommands() {
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);
  const { speak, cancel, speaking, supported: speechSupported } = useSpeechSynthesis();

  const { data: commands = [], isLoading } = useQuery<VoiceCommand[]>({
    queryKey: ['/api/voice-commands'],
  });

  const handleSpeak = (text: string) => {
    if (speaking) {
      cancel();
    } else {
      speak(text);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <TopBar
        title="Voice Commands"
        description="Interact with your AI assistant using voice commands"
      />
      
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Voice Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>Voice Input</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-4">
              <Button
                size="lg"
                onClick={() => setShowVoiceRecorder(true)}
                className="w-24 h-24 rounded-full bg-red-500 hover:bg-red-600"
              >
                <Mic size={32} />
              </Button>
              <div>
                <p className="font-medium text-gray-900">Click to start voice recording</p>
                <p className="text-sm text-gray-500 mt-1">
                  Speak naturally and your AI assistant will respond
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Task Management</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>"Create task for project review"</li>
                    <li>"Mark task as completed"</li>
                    <li>"Show me today's tasks"</li>
                  </ul>
                </div>
                
                <div className="p-4 bg-green-50 rounded-lg">
                  <h4 className="font-medium text-green-900 mb-2">AI Assistance</h4>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>"Help me with coding"</li>
                    <li>"Explain this concept"</li>
                    <li>"Start new conversation"</li>
                  </ul>
                </div>
                
                <div className="p-4 bg-purple-50 rounded-lg">
                  <h4 className="font-medium text-purple-900 mb-2">File Management</h4>
                  <ul className="text-sm text-purple-700 space-y-1">
                    <li>"Upload this document"</li>
                    <li>"Show my files"</li>
                    <li>"Delete old files"</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Voice Commands History */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Voice Commands</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                ))}
              </div>
            ) : commands.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Mic size={48} className="mx-auto mb-4 text-gray-300" />
                <p>No voice commands yet</p>
                <p className="text-sm">Start speaking to see your command history</p>
              </div>
            ) : (
              <div className="space-y-4">
                {commands.map((command) => (
                  <div
                    key={command.id}
                    className="p-4 bg-gray-50 rounded-lg border border-gray-200"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge
                            variant={command.success ? "default" : "destructive"}
                          >
                            {command.success ? "Success" : "Failed"}
                          </Badge>
                          <span className="text-sm text-gray-500">
                            {new Date(command.createdAt).toLocaleString()}
                          </span>
                        </div>
                        
                        <div className="space-y-2">
                          <div>
                            <p className="text-sm font-medium text-gray-700">Transcription:</p>
                            <p className="text-gray-900">{command.transcription}</p>
                          </div>
                          
                          {command.response && (
                            <div>
                              <p className="text-sm font-medium text-gray-700">Response:</p>
                              <p className="text-gray-900">{command.response}</p>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {command.response && speechSupported && (
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => handleSpeak(command.response!)}
                          className="ml-4"
                        >
                          {speaking ? <VolumeX size={16} /> : <Volume2 size={16} />}
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {showVoiceRecorder && (
        <VoiceRecorder onClose={() => setShowVoiceRecorder(false)} />
      )}
    </div>
  );
}
