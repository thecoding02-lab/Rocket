# Overview

This is a full-stack AI-powered personal assistant application built with React, Express, and PostgreSQL with **Replit Authentication** for secure user management. The application provides a comprehensive suite of productivity tools including task management, AI chat, voice commands, code assistance, learning analytics, and file storage. It features a modern interface built with shadcn/ui components and integrates with OpenAI's API for intelligent assistance across multiple domains.

## Recent Changes (August 5, 2025)
- **Added Replit Authentication**: Complete OAuth integration with session management
- **Updated Database Schema**: User table now supports Replit Auth with email, firstName, lastName, profileImageUrl
- **Secured All Endpoints**: All API routes now require authentication using isAuthenticated middleware
- **Landing Page**: Beautiful landing page for unauthenticated users
- **Authentication Flow**: Login/logout functionality with automatic redirects

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Form Handling**: React Hook Form with Zod validation

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful API with JSON responses
- **Database ORM**: Drizzle ORM for type-safe database operations
- **File Handling**: Multer for file uploads with size limits
- **Error Handling**: Centralized error middleware with proper HTTP status codes
- **Development**: Hot reloading with Vite integration in development mode

## Database Schema
- **Users**: Authentication and user management
- **Tasks**: Personal task management with categories, priorities, and due dates
- **Conversations & Messages**: AI chat history with role-based messaging
- **Voice Commands**: Voice interaction history with transcriptions
- **Files**: File storage metadata with descriptions and MIME types
- **Learning Data**: Analytics and insights storage for personalized learning

## Authentication & Session Management
- **Replit OAuth**: Full OpenID Connect integration with Replit as identity provider
- **Session Storage**: PostgreSQL-based session storage using connect-pg-simple for secure session management
- **Protected Routes**: All API endpoints secured with authentication middleware
- **User Context**: Real user identification from Replit OAuth claims across all endpoints
- **Landing Page**: Beautiful landing page for unauthenticated users with feature showcase

## AI Integration
- **OpenAI API**: GPT-4o model for chat completions and code assistance
- **Voice Processing**: Audio transcription capabilities
- **Sentiment Analysis**: Text analysis with confidence scoring
- **Contextual Memory**: Conversation history preservation for context-aware responses

## File Management
- **Upload Handling**: Multer-based file processing with 10MB size limits
- **Storage Strategy**: Local filesystem storage in uploads directory
- **Metadata Tracking**: Database storage of file information and descriptions
- **Type Classification**: MIME type-based file categorization

# External Dependencies

## Core Dependencies
- **@neondatabase/serverless**: Neon Database PostgreSQL client for serverless environments
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight React router
- **openai**: Official OpenAI API client

## UI & Styling
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant management
- **lucide-react**: Icon library

## Development Tools
- **vite**: Build tool and development server
- **typescript**: Type checking and development
- **tsx**: TypeScript execution for server development
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **@replit/vite-plugin-cartographer**: Replit-specific development tooling

## API Services
- **OpenAI API**: AI completions, chat, and transcription services
- **Neon Database**: Cloud PostgreSQL database service

## File & Media Processing
- **multer**: Multipart form data handling for file uploads
- **connect-pg-simple**: PostgreSQL session store for Express sessions

The application follows a modular architecture with clear separation of concerns, type safety throughout the stack, and integration with modern cloud services for scalability and performance.