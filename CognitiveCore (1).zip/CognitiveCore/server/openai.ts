import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function chatWithAI(messages: Array<{ role: string; content: string }>, systemPrompt?: string): Promise<string> {
  try {
    const chatMessages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [];
    
    if (systemPrompt) {
      chatMessages.push({
        role: "system",
        content: systemPrompt
      });
    }
    
    chatMessages.push(...messages.map(msg => ({
      role: msg.role as "user" | "assistant",
      content: msg.content
    })));

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: chatMessages,
      max_tokens: 1000,
    });

    return response.choices[0]?.message?.content || "I'm sorry, I couldn't generate a response.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate AI response");
  }
}

export async function transcribeAudio(audioFilePath: string): Promise<string> {
  try {
    const fs = await import("fs");
    const audioReadStream = fs.createReadStream(audioFilePath);

    const transcription = await openai.audio.transcriptions.create({
      file: audioReadStream,
      model: "whisper-1",
    });

    return transcription.text;
  } catch (error) {
    console.error("Audio transcription error:", error);
    throw new Error("Failed to transcribe audio");
  }
}

export async function analyzeCode(code: string, language: string, task: string): Promise<string> {
  try {
    const prompt = `You are a code analysis expert. Analyze the following ${language} code for the task: "${task}".

Provide a detailed analysis including:
1. Code quality assessment
2. Potential improvements
3. Security considerations
4. Performance optimization suggestions
5. Best practices recommendations

Code:
\`\`\`${language}
${code}
\`\`\``;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a senior software engineer and code reviewer. Provide constructive, actionable feedback."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 1500,
    });

    return response.choices[0]?.message?.content || "Unable to analyze the code.";
  } catch (error) {
    console.error("Code analysis error:", error);
    throw new Error("Failed to analyze code");
  }
}