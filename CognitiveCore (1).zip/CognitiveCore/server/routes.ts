import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertTaskSchema, 
  insertConversationSchema, 
  insertMessageSchema,
  insertVoiceCommandSchema,
  insertFileSchema,
  insertLearningDataSchema
} from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { chatWithAI, transcribeAudio, analyzeCode } from "./openai";

// Extend Request to include file property for multer
interface RequestWithFile extends Request {
  file?: Express.Multer.File;
}

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Statistics endpoint
  app.get("/api/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Task routes
  app.get("/api/tasks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tasks = await storage.getTasks(userId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskData = insertTaskSchema.parse({
        ...req.body,
        userId
      });
      const task = await storage.createTask(taskData);
      res.json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(400).json({ message: "Invalid task data" });
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = z.object({
        title: z.string().optional(),
        description: z.string().optional(),
        category: z.string().optional(),
        priority: z.string().optional(),
        status: z.string().optional(),
        completed: z.boolean().optional(),
        dueDate: z.date().optional(),
      }).parse(req.body);
      
      const task = await storage.updateTask(id, updates);
      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(400).json({ message: "Invalid update data" });
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteTask(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Conversation routes
  app.get("/api/conversations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversations = await storage.getConversations(userId);
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.post("/api/conversations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversationData = insertConversationSchema.parse({
        ...req.body,
        userId
      });
      const conversation = await storage.createConversation(conversationData);
      res.json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      res.status(400).json({ message: "Invalid conversation data" });
    }
  });

  // Message routes
  app.get("/api/conversations/:id/messages", async (req, res) => {
    try {
      const { id } = req.params;
      const messages = await storage.getMessages(id);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/conversations/:id/messages", async (req, res) => {
    try {
      const { id } = req.params;
      const messageData = insertMessageSchema.parse({
        ...req.body,
        conversationId: id
      });
      
      const message = await storage.createMessage(messageData);
      
      // If this is a user message, generate AI response
      if (messageData.role === "user") {
        try {
          const aiResponse = await chatWithAI(messageData.content);
          const aiMessage = await storage.createMessage({
            conversationId: id,
            role: "assistant",
            content: aiResponse
          });
          res.json({ userMessage: message, aiMessage });
        } catch (aiError) {
          console.error("Error generating AI response:", aiError);
          res.json({ userMessage: message, aiMessage: null });
        }
      } else {
        res.json({ userMessage: message });
      }
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(400).json({ message: "Invalid message data" });
    }
  });

  // Voice command routes
  app.get("/api/voice-commands", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const commands = await storage.getVoiceCommands(userId);
      res.json(commands);
    } catch (error) {
      console.error("Error fetching voice commands:", error);
      res.status(500).json({ message: "Failed to fetch voice commands" });
    }
  });

  app.post("/api/voice-commands", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const commandData = insertVoiceCommandSchema.parse({
        ...req.body,
        userId
      });
      const command = await storage.createVoiceCommand(commandData);
      res.json(command);
    } catch (error) {
      console.error("Error creating voice command:", error);
      res.status(400).json({ message: "Invalid voice command data" });
    }
  });

  // Audio transcription endpoint
  app.post("/api/transcribe", isAuthenticated, upload.single('audio'), async (req: RequestWithFile, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No audio file provided" });
      }

      const transcription = await transcribeAudio(req.file.path);
      
      // Clean up uploaded file
      fs.unlinkSync(req.file.path);
      
      res.json({ transcription });
    } catch (error) {
      console.error("Error transcribing audio:", error);
      res.status(500).json({ message: "Failed to transcribe audio" });
    }
  });

  // File upload routes
  app.get("/api/files", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const files = await storage.getFiles(userId);
      res.json(files);
    } catch (error) {
      console.error("Error fetching files:", error);
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  app.post("/api/files", isAuthenticated, upload.single('file'), async (req: RequestWithFile, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      if (!req.file) {
        return res.status(400).json({ message: "No file provided" });
      }

      const fileData = insertFileSchema.parse({
        userId,
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        path: req.file.path,
        description: req.body.description || ""
      });

      const file = await storage.createFile(fileData);
      res.json(file);
    } catch (error) {
      console.error("Error uploading file:", error);
      res.status(400).json({ message: "Invalid file data" });
    }
  });

  app.delete("/api/files/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const file = await storage.getFile(id);
      
      if (file) {
        // Delete physical file
        if (fs.existsSync(file.path)) {
          fs.unlinkSync(file.path);
        }
        await storage.deleteFile(id);
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting file:", error);
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Learning data routes
  app.get("/api/learning-data", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const category = req.query.category as string;
      const data = category 
        ? await storage.getLearningDataByCategory(userId, category)
        : await storage.getLearningData(userId);
      res.json(data);
    } catch (error) {
      console.error("Error fetching learning data:", error);
      res.status(500).json({ message: "Failed to fetch learning data" });
    }
  });

  app.post("/api/learning-data", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const learningData = insertLearningDataSchema.parse({
        ...req.body,
        userId
      });
      const data = await storage.createLearningData(learningData);
      res.json(data);
    } catch (error) {
      console.error("Error creating learning data:", error);
      res.status(400).json({ message: "Invalid learning data" });
    }
  });

  // AI Chat endpoint for quick responses
  app.post("/api/ai/chat", isAuthenticated, async (req, res) => {
    try {
      const { message } = req.body;
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ message: "Message is required" });
      }

      const response = await chatWithAI([{ role: 'user', content: message }]);
      res.json({ response });
    } catch (error) {
      console.error("Error in AI chat:", error);
      res.status(500).json({ message: "Failed to get AI response" });
    }
  });

  // Code analysis endpoint
  app.post("/api/ai/analyze-code", isAuthenticated, async (req, res) => {
    try {
      const { code, language, task } = req.body;
      if (!code || !language || !task) {
        return res.status(400).json({ message: "Code, language, and task are required" });
      }

      const analysis = await analyzeCode(code, language, task);
      res.json({ analysis });
    } catch (error) {
      console.error("Error analyzing code:", error);
      res.status(500).json({ message: "Failed to analyze code" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
