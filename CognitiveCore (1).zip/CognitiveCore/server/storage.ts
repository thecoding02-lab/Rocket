import { 
  type User, 
  type UpsertUser,
  type Task,
  type InsertTask,
  type Conversation,
  type InsertConversation,
  type Message,
  type InsertMessage,
  type VoiceCommand,
  type InsertVoiceCommand,
  type File,
  type InsertFile,
  type LearningData,
  type InsertLearningData,
  users,
  tasks,
  conversations,
  messages,
  voiceCommands,
  files,
  learningData
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User methods - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Task methods
  getTasks(userId: string): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, updates: Partial<InsertTask>): Promise<Task>;
  deleteTask(id: string): Promise<void>;

  // Conversation methods
  getConversations(userId: string): Promise<Conversation[]>;
  getConversation(id: string): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  deleteConversation(id: string): Promise<void>;

  // Message methods
  getMessages(conversationId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;

  // Voice command methods
  getVoiceCommands(userId: string): Promise<VoiceCommand[]>;
  createVoiceCommand(command: InsertVoiceCommand): Promise<VoiceCommand>;

  // File methods
  getFiles(userId: string): Promise<File[]>;
  getFile(id: string): Promise<File | undefined>;
  createFile(file: InsertFile): Promise<File>;
  deleteFile(id: string): Promise<void>;

  // Learning data methods
  getLearningData(userId: string): Promise<LearningData[]>;
  getLearningDataByCategory(userId: string, category: string): Promise<LearningData[]>;
  createLearningData(data: InsertLearningData): Promise<LearningData>;
  updateLearningData(id: string, updates: Partial<InsertLearningData>): Promise<LearningData>;

  // Statistics methods
  getStats(userId: string): Promise<{
    totalTasks: number;
    completedTasks: number;
    conversations: number;
    voiceCommands: number;
    codeAssists: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getTasks(userId: string): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(eq(tasks.userId, userId))
      .orderBy(desc(tasks.createdAt));
  }

  async getTask(id: string): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || undefined;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values(task)
      .returning();
    return newTask;
  }

  async updateTask(id: string, updates: Partial<InsertTask>): Promise<Task> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    return updatedTask;
  }

  async deleteTask(id: string): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  async getConversations(userId: string): Promise<Conversation[]> {
    return await db
      .select()
      .from(conversations)
      .where(eq(conversations.userId, userId))
      .orderBy(desc(conversations.updatedAt));
  }

  async getConversation(id: string): Promise<Conversation | undefined> {
    const [conversation] = await db.select().from(conversations).where(eq(conversations.id, id));
    return conversation || undefined;
  }

  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const [newConversation] = await db
      .insert(conversations)
      .values(conversation)
      .returning();
    return newConversation;
  }

  async deleteConversation(id: string): Promise<void> {
    await db.delete(conversations).where(eq(conversations.id, id));
  }

  async getMessages(conversationId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.createdAt);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db
      .insert(messages)
      .values(message)
      .returning();
    return newMessage;
  }

  async getVoiceCommands(userId: string): Promise<VoiceCommand[]> {
    return await db
      .select()
      .from(voiceCommands)
      .where(eq(voiceCommands.userId, userId))
      .orderBy(desc(voiceCommands.createdAt));
  }

  async createVoiceCommand(command: InsertVoiceCommand): Promise<VoiceCommand> {
    const [newCommand] = await db
      .insert(voiceCommands)
      .values(command)
      .returning();
    return newCommand;
  }

  async getFiles(userId: string): Promise<File[]> {
    return await db
      .select()
      .from(files)
      .where(eq(files.userId, userId))
      .orderBy(desc(files.createdAt));
  }

  async getFile(id: string): Promise<File | undefined> {
    const [file] = await db.select().from(files).where(eq(files.id, id));
    return file || undefined;
  }

  async createFile(file: InsertFile): Promise<File> {
    const [newFile] = await db
      .insert(files)
      .values(file)
      .returning();
    return newFile;
  }

  async deleteFile(id: string): Promise<void> {
    await db.delete(files).where(eq(files.id, id));
  }

  async getLearningData(userId: string): Promise<LearningData[]> {
    return await db
      .select()
      .from(learningData)
      .where(eq(learningData.userId, userId))
      .orderBy(desc(learningData.updatedAt));
  }

  async getLearningDataByCategory(userId: string, category: string): Promise<LearningData[]> {
    return await db
      .select()
      .from(learningData)
      .where(and(eq(learningData.userId, userId), eq(learningData.category, category)))
      .orderBy(desc(learningData.updatedAt));
  }

  async createLearningData(data: InsertLearningData): Promise<LearningData> {
    const [newData] = await db
      .insert(learningData)
      .values(data)
      .returning();
    return newData;
  }

  async updateLearningData(id: string, updates: Partial<InsertLearningData>): Promise<LearningData> {
    const [updatedData] = await db
      .update(learningData)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(learningData.id, id))
      .returning();
    return updatedData;
  }

  async getStats(userId: string): Promise<{
    totalTasks: number;
    completedTasks: number;
    conversations: number;
    voiceCommands: number;
    codeAssists: number;
  }> {
    const [taskStats] = await db
      .select({
        total: sql<number>`count(*)::int`,
        completed: sql<number>`count(case when completed = true then 1 end)::int`
      })
      .from(tasks)
      .where(eq(tasks.userId, userId));

    const [conversationCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(conversations)
      .where(eq(conversations.userId, userId));

    const [voiceCommandCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(voiceCommands)
      .where(eq(voiceCommands.userId, userId));

    // Code assists could be tracked as a category in learning data or voice commands
    const [codeAssists] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(voiceCommands)
      .where(and(eq(voiceCommands.userId, userId), eq(voiceCommands.command, 'code_assist')));

    return {
      totalTasks: taskStats?.total || 0,
      completedTasks: taskStats?.completed || 0,
      conversations: conversationCount?.count || 0,
      voiceCommands: voiceCommandCount?.count || 0,
      codeAssists: codeAssists?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
